
 ADT - Artificial Double Tracking
_______________________________________

 v1.0.8, 2010-02-11 

 A AudioUnit PlugIn which emulates Artificial Double Tracking invented
 by the Beatles at Abbey Road Studios.

 Takes a mono input signal and generates a stereo signal with the original
 signal panned hard-left and the ADT signal panned hard-right.

 Update in version 1.0.7: also works on Stereo tracks and automatically
 sums the stereo signal to mono.

 (c) 2007-2010, Olaf Matthes 


Controls:

 - Delay: the time the ADT signal is delayed, 10 - 50 ms

 - Level: the level of the original signal 

 - ADT Level: the level of the ADT signal 

 - ADT Pan: the pan position of the ADT signal, the original signal is
            positioned at the opposite side 

 - Wow: amount of low frequency playback speed variation, 0 - 0.2%

 - WowFreq.: low frequency playback speed variation rate, 0 - 6Hz

 - Flutter: amount of high frequency playback speed variation, 0 - 0.2%

 - FlutFreq.: high frequency playback speed variation rate, 4 - 60Hz



Installation:

 Drop ADT.component into /Library/Audio/Plug-Ins/Components.

 This software was downloaded from: http://www.vacuumsound.de/

